#ifndef KEYMAP_H
#define KEYMAP_H

#include <map>
#include <vector>

namespace Input
{
	struct Keymap
	{
		std::vector<std::pair<std::string, int>> keys;
		
		Keymap();
	};
}

#endif